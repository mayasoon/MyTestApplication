package com.stay4it.model;

/**
 * Created by Stay on 4/4/16.
 * Powered by www.stay4it.com
 */
public class ConstantValues {
//        fetch from http://gank.io/api
    public static String[] images = {
            "http://ww3.sinaimg.cn/large/7a8aed7bjw1f2h04lir85j20fa0mx784.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bjw1f2fuecji0lj20f009oab3.jpg",

            "http://ww1.sinaimg.cn/large/610dc034jw1f2ewruruvij20d70miadg.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bjw1f2cfxa9joaj20f00fzwg2.jpg",

            "http://ww1.sinaimg.cn/large/610dc034gw1f2cf4ulmpzj20dw0kugn0.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1f27uhoko12j20ez0miq4p.jpg",

            "http://ww2.sinaimg.cn/large/610dc034jw1f27tuwswd3j20hs0qoq6q.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bjw1f26lox908uj20u018waov.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bjw1f25gtggxqjj20f00b9tb5.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1f249fugof8j20hn0qogo4.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1f20ruz456sj20go0p0wi3.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1f1yjc38i9oj20hs0qoq6k.jpg",

            "http://ww3.sinaimg.cn/large/610dc034gw1f1yj0vc3ntj20e60jc0ua.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1f1xad7meu2j20dw0ku0vj.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1f1w5m7c9knj20go0p0ae4.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1f1so7l2u60j20zk1cy7g9.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1f1rmqzruylj20hs0qon14.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bjw1f1qed6rs61j20ss0zkgrt.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bjw1f1p77v97xpj20k00zkgpw.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1f1o75j517xj20u018iqnf.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1f1klhuc8w5j20d30h9gn8.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1f1jionqvz6j20hs0qoq7p.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bjw1f1ia8qj5qbj20nd0zkmzp.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bjw1f1h4f51wbcj20f00lddih.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1f1g2xpx9ehj20ez0mi0vc.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1f1cl3c7rfgj20dw0ku76t.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1f1bdal8i3nj20f00lf77g.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bjw1f1a47fpjacj20f00imtam.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1f19241kkpwj20f00hfabt.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bjw1f17x6wmh09j20f00m1mzh.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1f14fbwrfptj20zk0npgtu.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bjw1f138l9egrmj20f00mbdij.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1f1052bhjauj20f00l6q4o.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bgw1f0orab74l4j20go0p0jw5.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bgw1f0k67zz05jj20ku0rs0y1.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bgw1f0k67eluxej20fr0m8whw.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bgw1f0k6706308j20vg18gqfl.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bgw1f0k66sk2qbj20rs130wqf.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bgw1f0ixu5rmtcj20hs0qojv5.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1f0f9fkzu78j20f00qo0xl.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bjw1f0e4suv1tgj20hs0qo0w5.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bjw1f0cw7swd9tj20hy0qogoo.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bjw1f0buzmnacoj20f00liwi2.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1f0bifjrh39j20v018gwtj.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1f082c0b6zyj20f00f0gnr.jpg",

            "http://ww3.sinaimg.cn/large/610dc034jw1f070hyadzkj20p90gwq6v.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1f05pbp0p0yj20go0mu77b.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1f04m5ngwwaj20dw0kmwgn.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1f03emebr4jj20ez0qoadk.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1ezzaw04857j20p00gp40w.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1ezysj9ytj5j20f00m8wh0.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bjw1ezxog636o8j20du0kujsg.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bjw1ezwgshzjpmj21ao1y0tf0.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bjw1ezvbmuqz9cj20hs0qoq6o.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1ezrtpmdv45j20u00spahy.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1ezqon28qrzj20h80pamze.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bjw1ezplg7s8mdj20xc0m8jwf.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bjw1ezodh37eadj20n90qotfr.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1ezn79ievhzj20p00odwhr.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bjw1ezil3n0cqdj20p00ou776.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bjw1ezhh5rh1r9j20hs0qoadi.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bjw1ezgal5vpjfj20go0p0adq.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1ezf3wrxcx2j20p011i7b2.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bjw1ezbriom623j20hs0qoadv.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1ezak8074s3j20qo0k0adz.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1ez9bkpuvipj20dw0kutb9.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1ez5zq5g685j20hj0qo0w1.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bgw1eyz0s7ro75j20qo0hsgny.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bgw1eyz0rg13v9j20hs0qon28.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bgw1eyz0qixq0wj20hr0qoaek.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bgw1eyz0pe9m1nj20ol0gwdka.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bgw1eyz0ni2r15j21kw2dcq8x.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bgw1eyvkh5wnbsj20qo0hsn0e.jpg",

            "http://ww1.sinaimg.cn/large/610dc034gw1eyvgnb0nm5j20zk1dvtmy.jpg",

            "http://ww1.sinaimg.cn/large/610dc034gw1eyu8kqv2p6j20m80rsjuy.jpg",

            "http://ww2.sinaimg.cn/large/610dc034gw1eyt23vp9mdj20ex0miq65.jpg",

            "http://ww2.sinaimg.cn/large/610dc034gw1eyrfnh1fcuj20ey0mi3zz.jpg",

            "http://ww2.sinaimg.cn/large/610dc034gw1eyrfi5kot7j20f00f0q5o.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1eynh92kg6jj20dc0gqwho.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bjw1eymacvzrz6j20e00k0gnm.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bjw1eyl43vfbndj20dw0ijmye.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1eyk28taztqj20hs0qotb8.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1eyirmivmh6j20f80m7abx.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1eyfe319rvfj20hs0qo41p.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bjw1eye51p41xlj20go0m8mz0.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bjw1eyd07uugyvj20qo0hqgom.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bjw1eybuo04j6dj20hq0qon0s.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1eyaov0c9z4j20iz0sg40t.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bjw1ey77s2wab8j20zk0nmdm2.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bjw1ey6238m03pj20gy0op77l.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1ey4w5cdjbej20hs0qoq7q.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1ey3ptkta45j20hs0qomzy.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1ey2lc2h2ckj20o20gxacp.jpg",

            "http://ww3.sinaimg.cn/large/7a8aed7bgw1exz7lm0ow0j20qo0hrjud.jpg",

            "http://ww2.sinaimg.cn/large/7a8aed7bjw1exy13si92lj20v218g10h.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1exwto3cm5xj20nm0kq7a3.jpg",

            "http://ww1.sinaimg.cn/large/7a8aed7bjw1exvmxmy36wj20ru114gqq.jpg",

            "http://ww3.sinaimg.cn/large/a3bcec5fjw1exukiyu2zoj20hs0qo0w9.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1exr0p4r0h3j20oy15445o.jpg",

            "http://ww4.sinaimg.cn/large/7a8aed7bjw1exp4h479xfj20hs0qoq6t.jpg",
    };
}
