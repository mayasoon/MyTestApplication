package com.stay4it.model;

/**
 * Created by Stay on 13/4/16.
 * Powered by www.stay4it.com
 */
public class Benefit {

    public String _id;
    public String createdAt;
    public String desc;
    public String publishedAt;
    public String source;
    public String type;
    public String url;
    public boolean used;
    public String who;

}
