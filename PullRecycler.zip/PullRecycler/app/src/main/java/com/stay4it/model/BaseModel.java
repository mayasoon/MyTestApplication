package com.stay4it.model;

/**
 * Created by Stay on 13/4/16.
 * Powered by www.stay4it.com
 */
public class BaseModel<T> {
    public boolean error;
    public T results;
}
